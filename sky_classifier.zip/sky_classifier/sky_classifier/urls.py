from django.contrib import admin
from django.urls import path, include  # Import include to link app URLs
from django.conf import settings  # Import settings for media configurations
from django.conf.urls.static import static  # Import static for serving media files

urlpatterns = [
    path('admin/', admin.site.urls),  # Route for the admin panel
    path('', include('classify.urls')),  # Include classify app's URLs at the root
]

# Serve media files during development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
