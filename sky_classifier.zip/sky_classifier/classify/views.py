import os
from django.shortcuts import render
from django.conf import settings
from tensorflow.keras.models import load_model
from tensorflow.keras.utils import img_to_array, load_img
import numpy as np

# Path to the .keras model
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'model', 'sky_model.keras')

# Load the pre-trained model
try:
    model = load_model(MODEL_PATH)
    print("Model loaded successfully.")
except Exception as e:
    print(f"Error loading model: {e}")

# Class names corresponding to your model's output
CLASS_NAMES = ['Cloudy', 'Overcast', 'Sunny']

def upload_image(request):
    if request.method == 'POST' and request.FILES.get('image'):
        # Get the uploaded file
        image = request.FILES['image']
        print(f"Uploaded image name: {image.name}")

        # Save the image to the media directory
        temp_image_path = os.path.join(settings.MEDIA_ROOT, image.name)
        print(f"Temporary image path: {temp_image_path}")

        try:
            with open(temp_image_path, 'wb+') as destination:
                for chunk in image.chunks():
                    destination.write(chunk)
            print("Image saved successfully.")
        except Exception as e:
            print(f"Error saving image: {e}")
            return render(request, 'classify/upload.html', {'error': "Failed to save the image."})

        # Preprocess and predict
        try:
            # Preprocess the image
            img = load_img(temp_image_path, target_size=(128, 128))  # Resize to model input size
            img_array = img_to_array(img) / 255.0  # Normalize pixel values
            img_array = np.expand_dims(img_array, axis=0)  # Add batch dimension
            print("Image preprocessed for the model.")

            # Make the prediction
            prediction = model.predict(img_array)
            predicted_class = CLASS_NAMES[np.argmax(prediction)]
            print(f"Prediction: {predicted_class}")
        except Exception as e:
            print(f"Error during prediction: {e}")
            return render(request, 'classify/upload.html', {'error': "Failed to process the image for prediction."})

        # Render the result
        return render(request, 'classify/result.html', {
            'image_url': f'/media/{image.name}',  # Serve the uploaded image from /media/
            'prediction': predicted_class,
        })

    # Handle the GET request (or no image uploaded)
    return render(request, 'classify/upload.html')
